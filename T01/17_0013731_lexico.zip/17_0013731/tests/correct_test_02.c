int func2(int i80)
{
  return i80 * 80 + 1;
}

/*
  int func (int i) {
    return i + 2;
  }
*/