int a @80 = 10;

\ float list AL;