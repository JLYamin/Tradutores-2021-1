int a = 100+0;
int b = 90-10;
int c = 80/20;
int d = 70*30;
int e = "40a;

if (10==10) {
  if (21>10) {
    if (22^) {
      writeln("60a");
    }
  }
}
